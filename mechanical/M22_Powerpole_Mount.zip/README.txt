                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2580868
M22 Powerpole Mount by LA2YUA is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a M22 size panel mount adapter for standard 15-45A Powerpoles commonly used in amateur radio. 
When installed the connector is basically flush with the front of the mounting adapter, I've tested this with connectors with the typical rubber strain relief and there's plenty of clearance.

Thread pitch is 2 mm to simplify printing.

The design includes a screw that holds the Powerpole including clearance for the dovetails ensuring it can only be inserted one way. 
The screw includes two flats spaced at 19mm (3/4") to simplify installation.
A matching nut is also included for printing, a 26mm wrench can be used for tightening.

The rear port is large enough to insert the wires after installation if desired.
The Powerpole can either be glued in from the back, or retained using an M2.5 screw through the cross-hole in the screw.

To use the cross-hole you can install a DIN912 style M2.5x10-16 screw and rely on a friction fit. 
Optionally you can install a standard M2.5 brass insert (3.8mm outer diameter, 3-4mm length) to better retain the screw, use a M2.5x16 DIN912 screw in that case.

Note: you'll need to be able to print the inner dimensions of the screw to within +-0.1mm, otherwise you may have issues seating the plug. It's designed as a clearance fit so if it's too tight to get in then your print is too small.

In the power supply picture I used 30mm as the hole spacing (center to center), to drill the holes in thin sheet metal a stepped cone drill is a good choice.

Update: 2017-10-14:
I added a v5 DDWG for the screw that includes some additional measurements.

Added a _Rear variant of the screw which allow rear mounting of the powerpole and some other minor changes to chamfering (front is less chamfered and I removed the dovetail-slots from the front).
This should be more convenient, especially for semi-permanent install since you can pull out the powerpole without disconnecting the wires.
The thread of this variant is full length to allow installation in very thin panels.

A new smaller-diameter nut is included, this has 6 additional flats to reduce the OD to 28mm instead of 30mm.